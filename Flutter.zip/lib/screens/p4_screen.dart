import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class P4Screen extends StatefulWidget {
  @override
  _P4ScreenState createState() => _P4ScreenState();
}

class _P4ScreenState extends State<P4Screen> {
  int _counter = 0;
  bool _isCounting = false;
  int _timeLeft = 10;
  Timer? _timer;
  int _highScore = 0;
  List<int> _scores = [];
  String _filePath = '';

  @override
  void initState() {
    super.initState();
    _initFilePath();
    _loadHighScore();
  }

  Future<void> _initFilePath() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      _filePath = '${directory.path}/scores.txt';
      await _createFileIfNeeded();
    } catch (e) {
      print('Error al crear el archivo: $e');
    }
  }

  Future<void> _createFileIfNeeded() async {
    try {
      final file = File(_filePath);
      if (!await file.exists()) {
        await file.writeAsString('');
        print('Archivo $_filePath creado.');
      }
    } catch (e) {
      print('Error al crear el archivo: $e');
    }
  }

  void _loadHighScore() async {
    try {
      final file = File(_filePath);
      final contents = await file.readAsString();
      if (contents.isNotEmpty) {
        final scores = contents.split('\n').where((line) => line.isNotEmpty).map(int.parse).toList();
        if (scores.isNotEmpty) {
          setState(() {
            _highScore = scores.reduce((a, b) => a > b ? a : b);
          });
        }
      }
    } catch (e) {
      print('Error al cargar el archivo: $e');
    }
  }

  void _saveScore() async {
    try {
      final file = File(_filePath);
      await file.writeAsString('$_counter\n', mode: FileMode.append);
      _scores.add(_counter);
      print('Puntuación guardada correctamente.');
    } catch (e) {
      print('Error al guardar la puntuación: $e');
    }
  }

  void _downloadScoreFile() async {
    try {
      final file = File(_filePath);
      final contents = await file.readAsString();
      final directory = await getApplicationDocumentsDirectory();
      final downloadPath = '${directory.path}/scores_download.txt';
      final downloadFile = File(downloadPath);
      await downloadFile.writeAsString(contents);
      print('Archivo descargado en: $downloadPath');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Archivo descargado en: $downloadPath'),
        ),
      );
    } catch (e) {
      print('Error al descargar el archivo: $e');
    }
  }

  void _startCountdown() {
    if (_isCounting) return;

    setState(() {
      _isCounting = true;
      _counter = 0;
      _timeLeft = 10;
    });

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        _timeLeft--;
      });

      if (_timeLeft == 0) {
        timer.cancel();
        _endGame();
      }
    });
  }

  void _incrementCounter() {
    if (!_isCounting) return;

    setState(() {
      _counter++;
    });
  }

  void _endGame() {
    setState(() {
      _isCounting = false;
    });

    if (_counter > _highScore) {
      setState(() {
        _highScore = _counter;
      });
    }

    _saveScore();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Tiempo terminado"),
        content: Text("Presionaste el botón $_counter veces en 10 segundos."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Aceptar"),
          ),
        ],
      ),
    );
  }

  void _stopApplication() {
    _downloadScoreFile();
    print('Aplicación detenida y archivo descargado.');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Práctica 4: Historial en Archivo'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Regresa a la pantalla principal
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1E1E1E), Color(0xFF121212)],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: EdgeInsets.all(10.0),
                  child: Text(
                    "Puntuación más alta: $_highScore",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              Text(
                "Tiempo restante: $_timeLeft s",
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 20),
              Text(
                "El botón ha sido presionado $_counter veces",
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _isCounting ? _incrementCounter : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor : Color(0xFFBB86FC), // Color morado
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  "Presionar",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _startCountdown,
                style: ElevatedButton.styleFrom(
                  backgroundColor : Color(0xFF6200EE), // Color morado oscuro
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  "Iniciar",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _stopApplication,
                style: ElevatedButton.styleFrom(
                  backgroundColor : Color(0xFF3700B3), // Color morado más oscuro
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  "Detener y descargar puntuaciones",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}