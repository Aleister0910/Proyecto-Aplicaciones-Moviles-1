import 'package:flutter/material.dart';
import 'database_helper.dart';

class P6Screen extends StatefulWidget {
  @override
  _P6ScreenState createState() => _P6ScreenState();
}

class _P6ScreenState extends State<P6Screen> {
  int _score = 0;
  int _highScore = 0;
  bool _isButtonEnabled = false;
  bool _isGameRunning = false;
  int _countdown = 10; // Contador regresivo de 10 segundos
  final DatabaseHelper _dbHelper = DatabaseHelper();
  List<Map<String, dynamic>> _allScores = []; // Lista de todos los resultados

  @override
  void initState() {
    super.initState();
    _loadHighScore();
    _loadAllScores();
  }

  void _loadHighScore() async {
    List<Map<String, dynamic>> scores = await _dbHelper.getScores();
    if (scores.isNotEmpty) {
      setState(() {
        _highScore = scores[0]['score'];
      });
    }
  }

  void _loadAllScores() async {
    List<Map<String, dynamic>> scores = await _dbHelper.getScores();
    setState(() {
      _allScores = scores;
    });
  }

  void _startGame() {
    setState(() {
      _isButtonEnabled = true;
      _isGameRunning = true;
      _score = 0;
      _countdown = 10; // Reiniciar el contador
    });

    // Iniciar el contador regresivo
    Future.doWhile(() async {
      await Future.delayed(Duration(seconds: 1));
      if (_countdown > 0) {
        setState(() {
          _countdown--;
        });
        return true; // Continuar el bucle
      } else {
        setState(() {
          _isButtonEnabled = false;
          _isGameRunning = false;
        });
        _dbHelper.insertScore(_score);
        _loadHighScore();
        _loadAllScores(); // Actualizar la lista de resultados
        return false; // Detener el bucle
      }
    });
  }

  void _incrementScore() {
    setState(() {
      _score++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Práctica 6: Historial en SQLite'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Regresa a la pantalla principal
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF1E1E1E), Color(0xFF121212)],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Puntuación más alta
              Text(
                'Puntuación más alta: $_highScore',
                style: TextStyle(
                  fontSize: 24,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 20),

              // Cronómetro
              Center(
                child: Text(
                  'Tiempo: $_countdown segundos',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
              SizedBox(height: 20),

              // Botones
              Center(
                child: Column(
                  children: [
                    ElevatedButton(
                      onPressed: _isGameRunning ? null : _startGame,
                      style: ElevatedButton.styleFrom(
                        backgroundColor : Color(0xFF6200EE), // Color morado oscuro
                        padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        'Iniciar',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: _isButtonEnabled ? _incrementScore : null,
                      style: ElevatedButton.styleFrom(
                        backgroundColor : Color(0xFFBB86FC), // Color morado
                        padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Text(
                        'Pulsar ($_score)',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),

              // Lista de todos los resultados
              Expanded(
                child: ListView.builder(
                  itemCount: _allScores.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Text(
                        'Puntuación: ${_allScores[index]['score']}',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                        ),
                      ),
                      subtitle: Text(
                        'ID: ${_allScores[index]['id']}',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white70,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}