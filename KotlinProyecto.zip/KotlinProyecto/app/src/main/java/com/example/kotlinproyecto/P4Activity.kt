package com.example.kotlinproyecto

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Timer
import kotlin.concurrent.timerTask

class P4Activity : AppCompatActivity() {

    private var counter = 0
    private var timeLeft = 10
    private var isCounting = false
    private var highScore = 0
    private lateinit var scoresFile: File

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_p4)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        val btnPress = findViewById<Button>(R.id.btnPress)
        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnDownload = findViewById<Button>(R.id.btnDownload)
        val tvCounter = findViewById<TextView>(R.id.tvCounter)
        val tvTimeLeft = findViewById<TextView>(R.id.tvTimeLeft)
        val tvHighScore = findViewById<TextView>(R.id.tvHighScore)

        scoresFile = File(filesDir, "scores.txt")
        if (!scoresFile.exists()) {
            scoresFile.createNewFile()
        }

        loadHighScore(tvHighScore)

        btnBack.setOnClickListener {
            finish()
        }

        btnPress.setOnClickListener {
            if (isCounting) {
                counter++
                tvCounter.text = "El botón ha sido presionado ($counter) veces"
            }
        }

        btnStart.setOnClickListener {
            startCountdown(tvCounter, tvTimeLeft, tvHighScore)
        }

        btnDownload.setOnClickListener {
            downloadScoreFile()
        }
    }

    private fun startCountdown(tvCounter: TextView, tvTimeLeft: TextView, tvHighScore: TextView) {
        if (isCounting) return

        isCounting = true
        counter = 0
        timeLeft = 10

        tvCounter.text = "El botón ha sido presionado ($counter) veces"
        tvTimeLeft.text = "Tiempo restante: ${timeLeft}s"

        Timer().scheduleAtFixedRate(timerTask {
            runOnUiThread {
                timeLeft--
                tvTimeLeft.text = "Tiempo restante: ${timeLeft}s"

                if (timeLeft == 0) {
                    isCounting = false
                    endGame(tvHighScore)
                }
            }
        }, 1000, 1000)
    }

    private fun endGame(tvHighScore: TextView) {
        if (counter > highScore) {
            highScore = counter
            tvHighScore.text = "Puntuación más alta: $highScore"
        }

        saveScore()
        showAlertDialog()
    }

    private fun saveScore() {
        scoresFile.appendText("$counter\n")
    }

    private fun loadHighScore(tvHighScore: TextView) {
        val scores = scoresFile.readLines().mapNotNull { it.toIntOrNull() }
        if (scores.isNotEmpty()) {
            highScore = scores.maxOrNull() ?: 0
            tvHighScore.text = "Puntuación más alta: $highScore"
        }
    }

    private fun downloadScoreFile() {
        val downloadFile = File(getExternalFilesDir(null), "scores_download.txt")
        scoresFile.copyTo(downloadFile, overwrite = true)
        AlertDialog.Builder(this)
            .setTitle("Archivo descargado")
            .setMessage("El archivo se ha guardado en: ${downloadFile.absolutePath}")
            .setPositiveButton("Aceptar", null)
            .show()
    }

    private fun showAlertDialog() {
        AlertDialog.Builder(this)
            .setTitle("Tiempo terminado")
            .setMessage("Presionaste el botón $counter veces en 10 segundos.")
            .setPositiveButton("Aceptar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}