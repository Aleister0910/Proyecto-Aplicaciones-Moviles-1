package com.example.kotlinproyecto

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class ScoreAdapter(private val context: Context, private val scores: List<Map<String, Any>>) : BaseAdapter() {

    override fun getCount(): Int = scores.size

    override fun getItem(position: Int): Any = scores[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false)
        val score = scores[position]

        view.findViewById<TextView>(android.R.id.text1).text = "Puntuación: ${score["score"]}"
        view.findViewById<TextView>(android.R.id.text2).text = "ID: ${score["id"]}"

        return view
    }
}