package com.example.kotlinproyecto

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView

class P2Activity : AppCompatActivity() {
    private var counter = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_p2)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        val btnPress = findViewById<Button>(R.id.btnPress)
        val tvCounter = findViewById<TextView>(R.id.tvCounter)

        btnBack.setOnClickListener {
            finish()
        }

        btnPress.setOnClickListener {
            counter++
            tvCounter.text = "El botón ha sido presionado ($counter) veces"
        }
    }
}