package com.example.kotlinproyecto

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnP1 = findViewById<Button>(R.id.btnP1)
        val btnP2 = findViewById<Button>(R.id.btnP2)
        val btnP3 = findViewById<Button>(R.id.btnP3)
        val btnP4 = findViewById<Button>(R.id.btnP4)
        val btnP5 = findViewById<Button>(R.id.btnP5)
        val btnP6 = findViewById<Button>(R.id.btnP6)

        btnP1.setOnClickListener {
            startActivity(Intent(this, P1Activity::class.java))
        }
        btnP2.setOnClickListener {
            startActivity(Intent(this, P2Activity::class.java))
        }
        btnP3.setOnClickListener {
            startActivity(Intent(this, P3Activity::class.java))
        }
        btnP4.setOnClickListener {
            startActivity(Intent(this, P4Activity::class.java))
        }
        btnP5.setOnClickListener {
            startActivity(Intent(this, P5Activity::class.java))
        }
        btnP6.setOnClickListener {
            startActivity(Intent(this, P6Activity::class.java))
        }
    }
}