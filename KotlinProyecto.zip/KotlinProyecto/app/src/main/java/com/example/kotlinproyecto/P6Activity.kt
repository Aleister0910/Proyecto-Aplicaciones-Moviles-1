package com.example.kotlinproyecto

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class P6Activity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var tvHighScore: TextView
    private lateinit var tvCountdown: TextView
    private lateinit var btnStart: Button
    private lateinit var btnPress: Button
    private lateinit var listView: ListView
    private lateinit var adapter: ScoreAdapter

    private var score = 0
    private var highScore = 0
    private var countdown = 10
    private var isButtonEnabled = false
    private var isGameRunning = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_p6)

        dbHelper = DatabaseHelper(this)
        tvHighScore = findViewById(R.id.tvHighScore)
        tvCountdown = findViewById(R.id.tvCountdown)
        btnStart = findViewById(R.id.btnStart)
        btnPress = findViewById(R.id.btnPress)
        listView = findViewById(R.id.scoreList)

        loadHighScore()
        loadAllScores()

        btnStart.setOnClickListener {
            startGame()
        }

        btnPress.setOnClickListener {
            if (isButtonEnabled) {
                score++
                btnPress.text = "Pulsar ($score)"
            }
        }
    }

    private fun startGame() {
        if (isGameRunning) return

        isGameRunning = true
        isButtonEnabled = true
        score = 0
        countdown = 10
        btnPress.text = "Pulsar ($score)"
        btnStart.isEnabled = false

        handler.postDelayed(object : Runnable {
            override fun run() {
                if (countdown > 0) {
                    countdown--
                    tvCountdown.text = "Tiempo: ${countdown} segundos"
                    handler.postDelayed(this, 1000)
                } else {
                    isGameRunning = false
                    isButtonEnabled = false
                    btnStart.isEnabled = true
                    saveScore()
                }
            }
        }, 1000)
    }

    private fun saveScore() {
        dbHelper.insertScore(score)
        loadHighScore()
        loadAllScores()
    }

    private fun loadHighScore() {
        val scores = dbHelper.getScores()
        if (scores.isNotEmpty()) {
            highScore = scores[0]["score"] as Int
            tvHighScore.text = "Puntuación más alta: $highScore"
        }
    }

    private fun loadAllScores() {
        val scores = dbHelper.getScores()
        adapter = ScoreAdapter(this, scores)
        listView.adapter = adapter
    }
}