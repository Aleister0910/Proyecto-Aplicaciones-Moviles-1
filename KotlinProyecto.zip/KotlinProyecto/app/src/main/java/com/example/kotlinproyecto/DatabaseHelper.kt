package com.example.kotlinproyecto

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "app_database.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_USERS = "users"
        private const val TABLE_SCORES = "scores"
        private const val COLUMN_ID = "id"
        private const val COLUMN_NAME = "name"
        private const val COLUMN_AGE = "age"
        private const val COLUMN_SCORE = "score"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        // Crear tabla de usuarios
        val createUsersTable = ("CREATE TABLE $TABLE_USERS ("
                + "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "$COLUMN_NAME TEXT,"
                + "$COLUMN_AGE INTEGER)")
        db?.execSQL(createUsersTable)

        // Crear tabla de puntuaciones
        val createScoresTable = ("CREATE TABLE $TABLE_SCORES ("
                + "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "$COLUMN_SCORE INTEGER)")
        db?.execSQL(createScoresTable)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_SCORES")
        onCreate(db)
    }

    // Métodos para la tabla de usuarios (Práctica 5)
    fun insertUser(name: String, age: Int): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_NAME, name)
        values.put(COLUMN_AGE, age)
        return db.insert(TABLE_USERS, null, values)
    }

    fun getUsers(): List<Map<String, Any>> {
        val users = mutableListOf<Map<String, Any>>()
        val db = this.readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_USERS", null)

        if (cursor.moveToFirst()) {
            do {
                val user = mapOf(
                    "id" to cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                    "name" to cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                    "age" to cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_AGE))
                )
                users.add(user)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return users
    }

    fun updateUser(id: Int, name: String, age: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_NAME, name)
        values.put(COLUMN_AGE, age)
        return db.update(TABLE_USERS, values, "$COLUMN_ID = ?", arrayOf(id.toString()))
    }

    fun deleteUser(id: Int): Int {
        val db = this.writableDatabase
        return db.delete(TABLE_USERS, "$COLUMN_ID = ?", arrayOf(id.toString()))
    }

    // Métodos para la tabla de puntuaciones (Práctica 6)
    fun insertScore(score: Int): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_SCORE, score)
        return db.insert(TABLE_SCORES, null, values)
    }

    fun getScores(): List<Map<String, Any>> {
        val scores = mutableListOf<Map<String, Any>>()
        val db = this.readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM $TABLE_SCORES ORDER BY $COLUMN_SCORE DESC", null)

        if (cursor.moveToFirst()) {
            do {
                val score = mapOf(
                    "id" to cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                    "score" to cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_SCORE))
                )
                scores.add(score)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return scores
    }
}