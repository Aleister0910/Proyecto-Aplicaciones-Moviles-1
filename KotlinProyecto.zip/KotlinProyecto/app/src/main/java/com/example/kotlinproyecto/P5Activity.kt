package com.example.kotlinproyecto

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class P5Activity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var listView: ListView
    private lateinit var adapter: UserAdapter
    private lateinit var nameInput: EditText
    private lateinit var ageInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_p5)

        dbHelper = DatabaseHelper(this)
        nameInput = findViewById(R.id.nameInput)
        ageInput = findViewById(R.id.ageInput)
        val addButton = findViewById<Button>(R.id.addButton)
        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        listView = findViewById(R.id.userList)

        loadUsers()

        addButton.setOnClickListener {
            val name = nameInput.text.toString()
            val age = ageInput.text.toString().toIntOrNull() ?: 0
            if (name.isNotEmpty() && age > 0) {
                dbHelper.insertUser(name, age)
                loadUsers()
                nameInput.text.clear()
                ageInput.text.clear()
            }
        }

        btnBack.setOnClickListener {
            finish()
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            val user = adapter.getItem(position) as Map<*, *>
            showEditDialog(user)
        }
    }

    private fun loadUsers() {
        val users = dbHelper.getUsers()
        adapter = UserAdapter(this, users)
        listView.adapter = adapter
    }

    private fun showEditDialog(user: Map<*, *>) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_user, null)
        val nameInput = dialogView.findViewById<EditText>(R.id.editNameInput)
        val ageInput = dialogView.findViewById<EditText>(R.id.editAgeInput)

        nameInput.setText(user["name"].toString())
        ageInput.setText(user["age"].toString())

        AlertDialog.Builder(this)
            .setTitle("Editar Usuario")
            .setView(dialogView)
            .setPositiveButton("Guardar") { _, _ ->
                val name = nameInput.text.toString()
                val age = ageInput.text.toString().toIntOrNull() ?: 0
                if (name.isNotEmpty() && age > 0) {
                    dbHelper.updateUser(user["id"] as Int, name, age)
                    loadUsers()
                }
            }
            .setNegativeButton("Eliminar") { _, _ ->
                dbHelper.deleteUser(user["id"] as Int)
                loadUsers()
            }
            .setNeutralButton("Cancelar", null)
            .show()
    }
}