package com.example.kotlinproyecto

import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Timer
import kotlin.concurrent.timerTask

class P3Activity : AppCompatActivity() {

    private var counter = 0
    private var timeLeft = 10
    private var isCounting = false
    private var isButtonEnabled = false
    private var timer: Timer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_p3)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        val btnPress = findViewById<Button>(R.id.btnPress)
        val btnStart = findViewById<Button>(R.id.btnStart)
        val tvCounter = findViewById<TextView>(R.id.tvCounter)
        val tvTimeLeft = findViewById<TextView>(R.id.tvTimeLeft)

        btnBack.setOnClickListener {
            finish()
        }

        btnPress.setOnClickListener {
            if (isButtonEnabled) {
                counter++
                tvCounter.text = "El botón ha sido presionado ($counter) veces"
            }
        }

        btnStart.setOnClickListener {
            startCountdown(tvCounter, tvTimeLeft, btnPress)
        }
    }

    private fun startCountdown(tvCounter: TextView, tvTimeLeft: TextView, btnPress: Button) {
        if (isCounting) return

        isCounting = true
        isButtonEnabled = true
        counter = 0
        timeLeft = 10

        tvCounter.text = "El botón ha sido presionado ($counter) veces"
        tvTimeLeft.text = "Tiempo restante: ${timeLeft}s"

        timer = Timer()
        timer?.scheduleAtFixedRate(timerTask {
            runOnUiThread {
                if (timeLeft > 1) {
                    timeLeft--
                    tvTimeLeft.text = "Tiempo restante: ${timeLeft}s"
                } else {
                    timeLeft = 0
                    isButtonEnabled = false
                    isCounting = false
                    tvTimeLeft.text = "Tiempo restante: ${timeLeft}s"
                    timer?.cancel()
                    showAlertDialog(counter)
                }
            }
        }, 1000, 1000)
    }

    private fun showAlertDialog(counter: Int) {
        AlertDialog.Builder(this)
            .setTitle("Tiempo terminado")
            .setMessage("Hiciste $counter clicks.")
            .setPositiveButton("Cerrar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }
}